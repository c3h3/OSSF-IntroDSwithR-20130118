darch
=====

Create deep architectures in the R programming language
